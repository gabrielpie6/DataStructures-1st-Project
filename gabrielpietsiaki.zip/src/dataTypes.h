#ifndef DATA_TYPES_H
#define DATA_TYPES_H

typedef void * Item;

#endif